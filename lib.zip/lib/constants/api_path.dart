class CodingChallengeAPI {
  CodingChallengeAPI._();

  static const String baseUrl = "https://api.stagingcupid.com/api/v1";

  static const String countriesUrl = "/countries";
  static const String stateUrl =
      "/countries/country_id/states"; //replace country_id with ID
}
